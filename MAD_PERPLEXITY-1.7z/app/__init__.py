from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate  # Added Flask-Migrate
from app.config import Config
import os

# Initialize extensions
db = SQLAlchemy()
migrate = Migrate()  # Added Migrate
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'info'

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)  # Initialize Flask-Migrate
    login_manager.init_app(app)

    # Import models **after** initializing `db` to avoid circular imports
    from app import models  

    # Import and register blueprints
    from app.routes import admin, user, auth
    app.register_blueprint(admin.bp)
    app.register_blueprint(user.bp)
    app.register_blueprint(auth.bp)

    return app



