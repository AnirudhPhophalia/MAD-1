from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from app.models import Subject, Chapter, Quiz, Question, Score, Feedback, Announcement
from app import db
from datetime import datetime, timedelta

bp = Blueprint('user', __name__)

@bp.route('/dashboard')
@login_required
def dashboard():
    subjects = Subject.query.all()
    return render_template('user/dashboard.html', subjects=subjects)

@bp.route('/subject/<int:subject_id>')
@login_required
def view_subject(subject_id):
    subject = Subject.query.get_or_404(subject_id)
    chapters = Chapter.query.filter_by(subject_id=subject.id).all()
    return render_template('user/view_subject.html', subject=subject, chapters=chapters)

@bp.route('/chapter/<int:chapter_id>')
@login_required
def view_chapter(chapter_id):
    chapter = Chapter.query.get_or_404(chapter_id)
    quizzes = Quiz.query.filter_by(chapter_id=chapter.id).all()
    return render_template('user/view_chapter.html', chapter=chapter, quizzes=quizzes)

@bp.route('/take_quiz/<int:quiz_id>', methods=['GET', 'POST'])
@login_required
def take_quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    questions = Question.query.filter_by(quiz_id=quiz.id).all()
    
    if request.method == 'POST':
        score = 0
        for question in questions:
            user_answer = request.form.get(f'question_{question.id}')
            if user_answer and int(user_answer) == question.correct_option:
                score += 1
        
        ist_time = datetime.utcnow() + timedelta(hours=5, minutes=30)

        new_score = Score(
            quiz_id=quiz.id,
            user_id=current_user.id,
            time_stamp_of_attempt=ist_time,
            total_scored=score
        )
        db.session.add(new_score)
        db.session.commit()
        
        flash(f'Quiz completed. Your score: {score}/{len(questions)}')
        return redirect(url_for('user.view_results', quiz_id=quiz.id))
    
    return render_template('user/take_quiz.html', quiz=quiz, questions=questions)

@bp.route('/view_results/<int:quiz_id>')
@login_required
def view_results(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    score = Score.query.filter_by(quiz_id=quiz.id, user_id=current_user.id).order_by(Score.time_stamp_of_attempt.desc()).first()
    feedback = Feedback.query.filter_by(quiz_id=quiz.id, user_id=current_user.id).order_by(Feedback.timestamp.desc()).first()
    return render_template('user/view_results.html', quiz=quiz, score=score, feedback=feedback)

@bp.route('/my_scores')
@login_required
def my_scores():
    scores = Score.query.filter_by(user_id=current_user.id).order_by(Score.time_stamp_of_attempt.desc()).all()
    return render_template('user/my_scores.html', scores=scores)

@bp.route('/notifications')
@login_required
def notifications():
    feedbacks = Feedback.query.filter_by(user_id=current_user.id).order_by(Feedback.timestamp.desc()).all()
    announcements = Announcement.query.order_by(Announcement.timestamp.desc()).all()
    return render_template('user/notifications.html', feedbacks=feedbacks, announcements=announcements)

@bp.route('/announcements')
@login_required
def view_announcements():
    announcements = Announcement.query.order_by(Announcement.timestamp.desc()).all()
    return render_template('user/announcements.html', announcements=announcements)
