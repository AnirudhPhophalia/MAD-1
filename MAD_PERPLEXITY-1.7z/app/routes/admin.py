from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app.models import User, Subject, Chapter, Quiz, Question, Score, Announcement, Feedback
from app import db
from datetime import datetime, timedelta

bp = Blueprint('admin', __name__, url_prefix='/admin')

@bp.route('/dashboard')
@login_required
def dashboard():
    if not current_user.is_admin:
        flash('You do not have permission to access this page.')
        return redirect(url_for('user.dashboard'))
    
    subjects = Subject.query.all()
    users = User.query.filter_by(is_admin=False).all()  # Get all non-admin users
    return render_template('admin/dashboard.html', subjects=subjects, users=users)



@bp.route('/create_subject', methods=['GET', 'POST'])
@login_required
def create_subject():
    if not current_user.is_admin:
        flash('You do not have permission to access this page.')
        return redirect(url_for('user.dashboard'))
    
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        subject = Subject(name=name, description=description)
        db.session.add(subject)
        db.session.commit()
        flash('Subject created successfully.')
        return redirect(url_for('admin.dashboard'))
    
    return render_template('admin/create_subject.html')

@bp.route('/edit_subject/<int:subject_id>', methods=['GET', 'POST'])
@login_required
def edit_subject(subject_id):
    if not current_user.is_admin:
        flash('You do not have permission to access this page.')
        return redirect(url_for('user.dashboard'))
    
    subject = Subject.query.get_or_404(subject_id)
    if request.method == 'POST':
        subject.name = request.form['name']
        subject.description = request.form['description']
        db.session.commit()
        flash('Subject updated successfully.')
        return redirect(url_for('admin.dashboard'))
    
    return render_template('admin/edit_subject.html', subject=subject)

@bp.route('/delete_subject/<int:subject_id>', methods=['POST'])
@login_required
def delete_subject(subject_id):
    if not current_user.is_admin:
        flash('You do not have permission to access this page.')
        return redirect(url_for('user.dashboard'))
    
    subject = Subject.query.get_or_404(subject_id)
    db.session.delete(subject)
    db.session.commit()
    flash('Subject deleted successfully.')
    return redirect(url_for('admin.dashboard'))

@bp.route('/create_chapter/<int:subject_id>', methods=['GET', 'POST'])
@login_required
def create_chapter(subject_id):
    if not current_user.is_admin:
        flash('You do not have permission to access this page.')
        return redirect(url_for('user.dashboard'))
    
    subject = Subject.query.get_or_404(subject_id)
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        
        if not name:
            flash('Chapter name is required.')
            return render_template('admin/create_chapter.html', subject=subject)
        
        chapter = Chapter(
            name=name,
            description=description,
            subject_id=subject.id
        )
        try:
            db.session.add(chapter)
            db.session.commit()
            flash('Chapter created successfully.')
            return redirect(url_for('admin.dashboard'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while creating the chapter.')
            return render_template('admin/create_chapter.html', subject=subject)
    
    return render_template('admin/create_chapter.html', subject=subject)


@bp.route('/create_quiz/<int:chapter_id>', methods=['GET', 'POST'])
@login_required
def create_quiz(chapter_id):
    if not current_user.is_admin:
        flash('You do not have permission to access this page.')
        return redirect(url_for('user.dashboard'))
    
    chapter = Chapter.query.get_or_404(chapter_id)
    if request.method == 'POST':
        date_of_quiz = datetime.strptime(request.form['date_of_quiz'], '%Y-%m-%d')
        time_duration = timedelta(minutes=int(request.form['time_duration']))
        remarks = request.form['remarks']
        quiz = Quiz(chapter_id=chapter.id, date_of_quiz=date_of_quiz, time_duration=time_duration, remarks=remarks)
        db.session.add(quiz)
        db.session.commit()
        flash('Quiz created successfully.')
        return redirect(url_for('admin.create_question', quiz_id=quiz.id))
    
    return render_template('admin/create_quiz.html', chapter=chapter)

@bp.route('/create_question/<int:quiz_id>', methods=['GET', 'POST'])
@login_required
def create_question(quiz_id):
    if not current_user.is_admin:
        flash('You do not have permission to access this page.')
        return redirect(url_for('user.dashboard'))
    
    quiz = Quiz.query.get_or_404(quiz_id)
    if request.method == 'POST':
        question = Question(
            quiz_id=quiz.id,
            question_statement=request.form['question_statement'],
            option1=request.form['option1'],
            option2=request.form['option2'],
            option3=request.form['option3'],
            option4=request.form['option4'],
            correct_option=int(request.form['correct_option'])
        )
        db.session.add(question)
        db.session.commit()
        flash('Question added successfully.')
        if 'add_another' in request.form:
            return redirect(url_for('admin.create_question', quiz_id=quiz.id))
        return redirect(url_for('admin.dashboard'))
    
    return render_template('admin/create_question.html', quiz=quiz)

@bp.route('/view_quiz/<int:quiz_id>')
@login_required
def view_quiz(quiz_id):
    if not current_user.is_admin:
        flash('You do not have permission to access this page.')
        return redirect(url_for('user.dashboard'))
    
    quiz = Quiz.query.get_or_404(quiz_id)
    questions = Question.query.filter_by(quiz_id=quiz.id).all()
    return render_template('admin/view_quiz.html', quiz=quiz, questions=questions)

@bp.route('/view_student_answers/<int:score_id>')
@login_required
def view_student_answers(score_id):
    if not current_user.is_admin:
        flash('You do not have permission to access this page.')
        return redirect(url_for('user.dashboard'))
    
    score = Score.query.get_or_404(score_id)
    quiz = score.quiz
    questions = Question.query.filter_by(quiz_id=quiz.id).all()
    return render_template('admin/view_student_answers.html', score=score, questions=questions)

@bp.route('/send_announcement', methods=['GET', 'POST'])
@login_required
def send_announcement():
    if not current_user.is_admin:
        flash('You do not have permission to access this page.')
        return redirect(url_for('user.dashboard'))

    if request.method == 'POST':
        title = request.form['title']
        message = request.form['message']
        announcement = Announcement(
            title=title,
            message=message,
            date_posted=datetime.utcnow()
        )
        try:
            db.session.add(announcement)
            db.session.commit()
            flash('Announcement sent successfully.')
            return redirect(url_for('admin.dashboard'))
        except Exception as e:
            db.session.rollback()
            flash('Error while sending the announcement.')
    
    return render_template('admin/send_announcement.html')


@bp.route('/send_feedback/<int:score_id>', methods=['GET', 'POST'])
@login_required
def send_feedback(score_id):
    if not current_user.is_admin:
        flash('You do not have permission to access this page.')
        return redirect(url_for('user.dashboard'))

    score = Score.query.get_or_404(score_id)

    if request.method == 'POST':
        feedback_text = request.form['feedback']
        feedback = Feedback(
            user_id=score.user_id,
            quiz_id=score.quiz_id,
            feedback=feedback_text,
            timestamp=datetime.utcnow()
        )
        db.session.add(feedback)
        db.session.commit()
        flash('Feedback sent successfully.')
        return redirect(url_for('admin.view_student_answers', score_id=score.id))

    return render_template('admin/send_feedback.html', score=score)

